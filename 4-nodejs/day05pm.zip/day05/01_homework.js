const express=require('express');
const querystring=require('querystring');
//创建web服务器
var server=express();
server.listen(8080);
//添加路由
server.get('/page',function(req,res){
  //响应文件
  res.sendFile(__dirname+'/page.html');
});
//根据表单请求创建路由
// post  /mypage
server.post('/mypage',function(req,res){
  //获取post请求的数据
  req.on('data',function(buf){
    var str=buf.toString();
	//查询字符串
	var obj=querystring.parse(str);
	var myid=obj.id; 
    res.send(`
	  ${myid.substr(6,4)}年
	  ${myid.substr(10,2)}月
	  ${myid.substr(12,2)}日 
	  性别
	  ${myid.substr(-2,1)%2==0?'女':'男'}
	`);
  });
});

