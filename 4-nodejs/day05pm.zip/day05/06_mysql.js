//引入mysql
const mysql=require('mysql');
//创建连接池对象，自动建立连接
var pool=mysql.createPool({
  host:'127.0.0.1',
  port:'3306',
  user:'root',
  password:'',
  database:'tedu',
  connectionLimit:20  //设置连接池的大小
});
//执行SQL语句
/*
pool.query('SELECT * FROM emp',function(err,result){
  if(err) throw err;
  console.log(result);
});

//往部门表中插入数据，查看结果
//var did=18;
//var dname='安保部';
// ?占位符, 防止SQL注入攻击数据库
pool.query('INSERT INTO dept VALUES(?,?)',[did,dname],function(err,result){
  if(err) throw err;
  console.log(result);
});

var obj={
  did:14,
  dname:'后勤部'
}
pool.query('INSERT INTO dept VALUES(?,?)',[obj.did,obj.dname],function(err,result){
  if(err) throw err;
  console.log(result);
})

var obj={
  did:21,
  dname:'财务部'
}
pool.query('INSERT INTO dept SET ?',[obj],function(err,result){
  if(err) throw err;
  console.log(result);
});
*/
//将部门表dept中编号为40的数据，部门名称改为“测试1部”
pool.query('UPDATE dept SET dname=? WHERE did=?',['测试1部',40],function(err,result){
  if(err) throw err;
  console.log(result);
});



