var obj=require('./03_2');
console.log(obj);
//调用导出的函数
obj.fn(2,3);