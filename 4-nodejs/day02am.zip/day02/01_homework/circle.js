function getLength(r){
  return 2*Math.PI*r;
}
function getArea(r){
  return Math.PI*Math.pow(r,2);
}
//导出两个函数
//module.exports.getLength=getLength;
//module.exports.getArea=getArea;
//module.exports.fn=function(){
//  console.log(1);
//}
//module.exports导出对象
//赋值对象给要导出的对象，exports和module.exports就不再指向同一个对象了
module.exports={
  eid:1,
  ename:'tom',
  sex:'男'
}
//false
console.log(module.exports===exports);



