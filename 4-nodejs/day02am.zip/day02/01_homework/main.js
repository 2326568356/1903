//引入circle.js
//模块的.js后缀名可以省略
var circle=require('./circle');
console.log(circle);
//调用两个函数
//console.log( circle.getLength(5).toFixed(1) );
//console.log( circle.getArea(5).toFixed(1) );
//circle.fn();