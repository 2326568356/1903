console.log('03_2/test.js');
//导出函数
module.exports.fn=function(a,b){
  console.log(a+b);
}