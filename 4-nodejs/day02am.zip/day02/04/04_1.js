//不以路径开头的目录模块，自动到node_modules目录中寻找04_2目录
require('04_2');