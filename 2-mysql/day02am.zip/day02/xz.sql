#设置客户端连接服务器端的编码为utf8
SET NAMES UTF8;
#先丢弃数据库xz，如果存在
DROP DATABASE IF EXISTS xz;
#创建数据库xz，设置存储的编码为UTF8
CREATE DATABASE xz CHARSET=UTF8;
#进入该数据库
USE xz;
#创建保存用户数据的表user
CREATE TABLE user(
  uid INT,
  uname VARCHAR(9),
  upwd VARCHAR(16),
  email VARCHAR(32),
  phone VARCHAR(11),
  sex VARCHAR(1),
  userName VARCHAR(4),
  regTime VARCHAR(10),   #2018-12-31
  isOnline INT    # 1是/0否
);
#插入数据
INSERT INTO user VALUES
('1','tom','123456','tom@163.com','18112345678','m','张三','2018-12-31','1'),
('2','king','123789','king@qq.com','19198766789','m','李四','2019-1-2','0'),
('3','kate','123789','kate@qq.com','19198766333','f','李四1','2019-3-2','1');
#修改数据 
UPDATE user SET upwd='666666',email='666@163.com' WHERE uid='2';
#删除数据
DELETE FROM user WHERE uid='3';
#查询数据
SELECT * FROM user;





