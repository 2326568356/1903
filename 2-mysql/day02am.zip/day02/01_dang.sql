#设置客户端连接服务器编码
SET NAMES UTF8;
#丢弃数据库dang,如果存在
DROP DATABASE IF EXISTS dang;
#创建数据库dang，设置存储的编码
CREATE DATABASE dang CHARSET=UTF8;
#进入该数据库
USE dang;
#创建数据表book
CREATE TABLE book(
  bid INT,
  title VARCHAR(16),
  author VARCHAR(8),
  price INT,
  publish VARCHAR(8),
  pubTime VARCHAR(10)
);
#插入数据
INSERT INTO book VALUES
('1','三国演义','罗贯中','87','人民邮电出版社','2002-10-1'),
('2','水浒传','施耐庵','79','清华大学出版社','2004-5-2'),
('3','西游记','吴承恩','66','中信出版社','2003-1-1'),
('4','红楼梦','曹雪芹','96','北京文学出版社','2003-1-1');




