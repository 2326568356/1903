//获取斐波那契数列的第n项
/*
function fib(n){
  //当n为1或者2的时候，直接返回1
  if(n==1 || n==2){
    return 1;
  }
  //当前这项的值=前两项相加的和
  return fib(n-1)+fib(n-2);
}
console.log( fib(20) );
*/
/*
fib(4)+fib(3)
fib(3)+fib(2)+fib(2)+fib(1)
fib(2)+fib(1)+fib(2)+fib(2)+fib(1)
*/
/*
var a=1;
var b=2;
//需要第三方的变量
var c=a;
a=b;
b=c;
console.log(a,b);
*/
function fib(n){
  //首先第一项和第二项的值都是1
  var n1=1;
  var n2=1;
  //如果要获取的第n项的值，需要从第3项开始，不断往后移动
  for(var i=3;i<=n;i++){
    //每移动一次，当前的n1为上一次n2的值，当前的n2为上一次n1和n2相加的值
    var c=n1;
    n1=n2;
	n2=c+n2;
  }
  //当前n2的值就是这一项的值
  return n2;
}
console.log( fib(100) );









