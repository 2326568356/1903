//匿名函数
//function(){  }
fn();
function fn(){  }
fn();

//使用匿名函数创建函数——函数表达式
//此时的变量名称就是函数名称

var fun=function(){
  console.log(1);
}
//调用函数
//fun();
//console.log(fun);
//练习：使用函数表达式创建函数，计算任意两个数字之间所有整数的和，并返回结果
var getSum=function(n1,n2){
  //循环获取n1~n2之间所有的整数
  for(var i=n1,sum=0;i<=n2;i++){
    sum+=i;
  }
  //返回结果
  return sum;
}
console.log( getSum(50,100) );


