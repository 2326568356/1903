var str1=1+'2'; // '12'
var str2='3'+'4'; // '34'
//console.log(str2,typeof str2);
var num=3+false;
//console.log(num,typeof num);
var str3='5'+true;//'5true'
//console.log(str3,typeof str3);
var num1=3,num2=true,num3='tedu';
/*
console.log(num1+num2+num3);//'4tedu'
console.log(num2+num3+num1);//'truetedu3'
console.log(num3+num1+num2);//'tedu3true'
*/

var num1=3-'2'; // 1
var num2=3-true;// 2
var num3='3'*'5';
var num4=20/'4'; 
//隐式将'a'转为数值型，返回NaN
var num5=3-'a';//NaN  Not a Number
var num6=1-undefined;//NaN
var num7=2-null;//2
var num8=3+NaN;
console.log(num8,typeof num8);







