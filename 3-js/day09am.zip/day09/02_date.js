//创建对象，存储日期时间
/*
var d1=new Date('2019/4/19 10:20:30');
var d2=new Date(2019,3,19,10,20,30);
//获取当前的系统时间
var d3=new Date();
//存储距离计算机元年的毫秒数
//1970-1-1 0:0:0
//1500000000000
var d4=new Date(1500000000000);
//console.log(d4);

//获取Date对象中的日期时间等
var d1=new Date();
console.log( d1.getFullYear() );
console.log( d1.getMonth()+1 );//0~11
console.log( d1.getDate() );
console.log( d1.getHours() );
console.log( d1.getMinutes() );
console.log( d1.getSeconds() );
console.log( d1.getMilliseconds() );
console.log( d1.getDay() );//0~4
console.log( d1.getTime() );

//练习：创建Date对象，保存当前系统的日期时间；根据对象打印  2019年04月19日  星期四
var now=new Date();
var year=now.getFullYear();
var month=now.getMonth()+1;
var date=now.getDate();
var day=now.getDay();//0~6
//判断月份是否小于10
if(month<10){
  //增加前导0
  month='0'+month;
}
//创建数组，保存中文的星期
var week=['星期日','星期一','星期二','星期三','星期四','星期五','星期六'];
console.log( year+'年'+month+'月'+date+'日 '+week[day] );
*/

//计算当前距离2019年国庆节还有？天？小时？分钟？秒
//计算两个日期时间相差的毫秒数
var now=new Date();
var target=new Date('2019/10/1');
//console.log( target.getTime()-now.getTime() );
//两个对象相减得到的就是相差的毫秒数
var d=target-now;
//转成相差的秒数
d=Math.floor(d/1000);
//获取相差的天数=总的秒数/一天的秒数
var day=Math.floor(d/(24*60*60));
//获取相差的小时
//获取相差不满一天的秒数，转成小时
// 总的秒数%一天的秒数
/*
一天二个小时 = 93600秒
24*60*60=86400秒    
7200 = 3600*2
*/
console.log(day);




