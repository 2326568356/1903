//创建数组，包含10个元素
/*
var arr=['html','css','js','nodejs','ajax','vue','react','angular','ionic','python'];
//取随机下标  0~9
//随机数  0~1 * 长度  0~9.999  向下取整
var index=Math.floor(Math.random()*10);
console.log( arr[index] );


//创建数组，包含a~z,A~Z,0~9
var arr=['a','b','c','d','e','f','g','A','B','C','D','E','F','G',0,1,2,3,4,5,6,7,8,9];
//0~23   24
//随机数 * 数组长度   向下取整
//0~1  * 24   0~23.999   0~23
//循环4次
var arr2=[];
for(var i=0;i<4;i++){
  //取随机下标
  var index=Math.floor(Math.random()*arr.length);
  //通过下标找元素
  //console.log(arr[index]);
  arr2.push( arr[index] );
  //在原来数组中删除取到的元素
  //pop shift splice
  arr.splice(index,1);
}
console.log(arr2);

*/
var str='hOw aRE yOu';
//将英文分隔成多个单词
//字符串按照空格分隔为数组
var arr=str.split(' ');
//遍历数组，将每个自单词的首字母转大写，其余字母转小写
for(var i=0;i<arr.length;i++){
  //取首字母
  var first=arr[i].slice(0,1).toUpperCase();
  //取取余字母
  var last=arr[i].slice(1).toLowerCase();
  //把转换的结果替换之前的
  arr[i]=first+last;
}
//将数组arr转为字符串
console.log(arr.join(' '));





