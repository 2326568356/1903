//使用字符串作为下标————关联数组
var person=[];
person['name']='tom';
person['age']=18;
console.log(person);