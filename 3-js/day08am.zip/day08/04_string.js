var str1='hello';
//将数据转成字符串，并返回对象
var str2=new String(1);
//console.log(str2,typeof str2);
//console.log(str2+2);
//将数组转为字符串，返回字符串
//toString()
var str3=String(true);
//console.log(str3,typeof str3);

//console.log('It\'s a dog');
//console.log('hello \nworld');
//console.log('a\tb');
//练习：打印出现 welcome to chi\na
console.log('welcome to chi\\na');
