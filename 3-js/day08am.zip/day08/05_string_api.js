var str='javascript';
//计算字符串的长度
//console.log( str.length );
//获取下标对应的字符
//console.log( str[2] );
//console.log( str.charAt(4) );
//练习：遍历字符串，打印出每一个字符（循环下标）
for(var i=0;i<str.length;i++){
  console.log(str[i],str.charAt(i));
}








