//计算任意三个数字相加的和，并把结果返回
function add(a,b,c){
  return a+b+c;
  //return后的代码不执行
  //console.log('hello');
}
//把函数的返回结果保存到变量中
var num1=add(3,7,12);
//console.log(num1);

//练习：创建函数getMax，返回任意两个数字中的最大值
function getMax(a,b){
  /*
  if(a>b){
    return a;
  }else{
    return b;
  }*/
  return a>b ? a : b;
}
var n1=getMax(131,56);
console.log(n1);


