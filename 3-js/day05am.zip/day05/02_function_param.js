//创建带有参数的函数
//计算任意两个数字相加的和
function add(num1,num2){
  //在调用的时候，实参的第一个值会赋给num1，实参的第二个值赋给num2;
  console.log(num1+num2);
}
//add(2,3);
//add(7,14);
//add(9,13);
//练习：创建函数，传递1个参数，计算1~任意数字之间的和。
function getSum(n){
  //计算1~n之间所有数字的和
  for(var i=1,sum=0;i<=n;i++){
    sum+=i;
  }
  console.log(sum);
}
//getSum(100);
//getSum(500);
//练习：创建函数，传递2个参数，计算任意两个年份之间的闰年个数
function getCount(n1,n2){
  //计算n1~n2之间的闰年个数
  for(var i=n1,sum=0;i<=n2;i++){
    //判断i是否为闰年，如果是sum++
	if(i%4==0 && i%100!=0 || i%400==0){
	  sum++;
	}
  }
  console.log(sum);
}
//getCount(2000,2100);
//getCount(1984,2022);


function add2(a,b,c){
  //形参未赋值结果也是undefined
  //console.log(c);
  console.log(a+b+c);
}
//add2(1,3);//NaN
//add2(2,4,6,8);
var num1=add(87,94,82);
console.log(num1);


