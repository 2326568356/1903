/*
console.log('hello');
console.log('world');
console.log('javascript');
*/
//创建函数 
function say(){
  console.log('hello');
  console.log('world');
  console.log('css');
}
//调用
//say();
//say();
//say();
//练习：使用函数封装1+2的计算结果，调用三次。
function add(){
  console.log(1+2);
}
//add();
//add();
//add();
//练习：使用函数封装计算1~100之间所有整数的和，并调用三次。
function getSum(){
  for(var i=1,sum=0;i<=100;i++){
    sum+=i;
  }
  console.log(sum);
}
getSum();
getSum();
getSum();




