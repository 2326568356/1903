var a='1';
//在原来基础之上加1
//a++;
//a=a+1;
//如果a是字符串，+=变成了字符串拼接
a+=1;
//console.log(a);

var price=28;
//原来基础之上打八折
price*=0.8;
console.log(price);






