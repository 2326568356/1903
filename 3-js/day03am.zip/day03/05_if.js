//满30减12
//如果订单金额满30，在原来的基础之上减12
var total=28;
if(total>=30){
  total-=12;
}
//console.log(total);
//练习：声明变量保存年龄，如果满18，打印成年人。
/*
var age=21;
if(age>=18){
  console.log('成年人'); 
}
*/
if(false){
  console.log(3);
}




